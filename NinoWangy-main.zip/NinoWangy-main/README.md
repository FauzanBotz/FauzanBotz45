<div align="center">
<img src="https://i.ibb.co/wMxq4RY/b092512ed0a0.jpg" alt="NinoWangy" width="300" />

# Nino Wangy

>
>
>
</div>
<p align="center">
  <a href="https://github.com/MhankBarBar"><img title="Author" src="https://img.shields.io/badge/Author-Mhankbarbar-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/6288286421519">KYAAA ONI CHAN >//< </a>
</h4>
</p>

## Update News
```bash
> Gelud
> Fix TicTacToe
> Ttg
> Togel
> Cekwatak
> Nekopoicosplay
> Nekopoi3d
```

## Note
```bash
> Kalo Mau Dapetin XP Aktifkan Leveling
> Balance dengan bermain game
```

## CARA INSTALL DI TERMUX
```bash
> git clone https://github.com/Nino-chan02/NinoWangy
> cd NinoWangy
> bash install.sh
> node index.js
```

# INSTALL
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://ffmpeg.org/download.html)
* [Libwebp](https://developers.google.com/speed/webp/download)

  # MAKASIH LORT
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`MhankBarBar`](https://github.com/MhankBarBar)
* [`Arip`](https://github.com/Akkun3704)
* [`Aqul`](https://github.com/zennn08)
* [`Hexa`](https://github.com/Hexagonz)
* [`Slavyan`](https://github.com/SlavyanDesu)
* [`Galang`](https://github.com/Zobin33)
* [`Franky`](https://github.com/Frankysolo)
  
  
